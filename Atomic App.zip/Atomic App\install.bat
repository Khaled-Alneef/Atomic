@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ===============================================
echo   Atomic App - Setup ^& Build
echo ===============================================
echo.

rem --- Locate a Python launcher --------------------------------------------
set "PYCMD="
where py >nul 2>nul
if %errorlevel%==0 set "PYCMD=py -3"
if not defined PYCMD (
    where python >nul 2>nul
    if %errorlevel%==0 set "PYCMD=python"
)

rem --- Install Python if none was found ------------------------------------
if not defined PYCMD (
    echo Python was not found on this system.
    where winget >nul 2>nul
    if %errorlevel% neq 0 (
        echo.
        echo winget is not available, so Python can't be installed automatically.
        echo Please install Python 3.10+ from https://www.python.org/downloads/
        echo ^(check "Add python.exe to PATH" during install^), then run this file again.
        pause
        exit /b 1
    )
    echo Installing Python 3.12 via winget - this may take a few minutes...
    winget install --id Python.Python.3.12 -e --source winget --accept-package-agreements --accept-source-agreements
    echo.
    echo Python was installed. Please close this window and double-click
    echo install.bat again so the updated PATH takes effect.
    pause
    exit /b 0
)

echo Using: %PYCMD%
echo.

rem --- Install dependencies (PyQt6, Pillow, PyInstaller) ---------------------
echo Installing required packages...
%PYCMD% -m pip install --upgrade pip >nul
%PYCMD% -m pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo.
    echo Failed to install dependencies. Check your internet connection and try again.
    pause
    exit /b 1
)

rem --- Build the standalone EXE ----------------------------------------------
echo.
echo Building Atomic.exe ...
%PYCMD% build.py
if %errorlevel% neq 0 (
    echo.
    echo Build failed - see the log above.
    pause
    exit /b 1
)

echo.
echo ===============================================
echo   Done! Your app is at: %~dp0dist\Atomic.exe
echo ===============================================
echo.
set /p LAUNCH="Launch it now? (Y/N): "
if /i "%LAUNCH%"=="Y" start "" "%~dp0dist\Atomic.exe"

pause
