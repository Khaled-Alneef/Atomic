"""Minimal client for Stremio's Cinemeta addon (https://v3-cinemeta.strem.io)
and a launcher for the Stremio desktop app. Search + a full-metadata
lookup for the latest aired episode, no API key needed. Every lookup
fails soft (returns []/None) so a flaky connection never crashes the
tracker UI - it just means no suggestions/covers/progress show up.
"""

import json
import urllib.parse
import urllib.request
import webbrowser
from datetime import datetime, timezone

BASE_URL = "https://v3-cinemeta.strem.io"
API_URL = "https://api.strem.io/api"


def search(query_text: str, content_type: str = "series", timeout: int = 6):
    """content_type: 'series' or 'movie'.

    Returns a list of dicts: {id, title, format, cover_url, stremio_url}.
    """
    query_text = (query_text or "").strip()
    if not query_text:
        return []

    encoded = urllib.parse.quote(query_text)
    url = f"{BASE_URL}/catalog/{content_type}/top/search={encoded}.json"
    req = urllib.request.Request(url, headers={
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 PC-App/1.0",
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return []

    metas = body.get("metas") or []
    results = []
    for m in metas:
        imdb_id = m.get("id") or ""
        if not imdb_id.startswith("tt"):
            continue
        results.append({
            "id": imdb_id,
            "title": m.get("name") or "Untitled",
            "format": m.get("year") or "",
            "cover_url": m.get("poster"),
            # Note the 3 slashes: "stremio://detail/..." makes Stremio's
            # protocol handler treat "detail" as an addon-manifest host
            # (it tries to fetch https://detail/... as a manifest, which
            # is the "Failed to get addon manifest" error). The extra
            # slash keeps the path in the path, not the host.
            #
            # No trailing videoId segment on purpose: appending one (even
            # the meta id itself) makes Stremio try to resolve a specific
            # episode/stream, landing on some arbitrary video instead of
            # the show's own overview page.
            "stremio_url": f"stremio:///detail/{content_type}/{imdb_id}",
        })
    return results


def _parse_aired(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def fetch_latest_episode(imdb_id: str, content_type: str = "series", timeout: int = 6):
    """Season/episode of the most recently aired episode, from Cinemeta's
    full episode list for this title (the catalog search used elsewhere
    doesn't include this - it's title/poster/year only). Used to prefill
    a new entry's progress with "here's the newest episode out" rather
    than leaving it blank. Specials (season 0) are skipped in favor of
    the latest numbered-season episode when both exist. Returns
    (season, episode) ints, or None if it can't be determined."""
    url = f"{BASE_URL}/meta/{content_type}/{imdb_id}.json"
    req = urllib.request.Request(url, headers={
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 PC-App/1.0",
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None

    videos = ((body.get("meta") or {}).get("videos")) or []
    now = datetime.now(timezone.utc)
    aired = []
    for v in videos:
        when = _parse_aired(v.get("firstAired"))
        if when and when <= now:
            aired.append((when, v))
    if not aired:
        return None

    numbered = [item for item in aired if (item[1].get("season") or 0) > 0]
    aired = numbered or aired
    aired.sort(key=lambda item: item[0])
    latest = aired[-1][1]
    return latest.get("season") or 0, latest.get("number") or latest.get("episode") or 0


def _api_post(path: str, payload: dict, timeout: int):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(f"{API_URL}/{path}", data=data, headers={
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 PC-App/1.0",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def login(email: str, password: str, timeout: int = 10) -> str:
    """Sign into a Stremio account via Stremio's own account API
    (api.strem.io - the same one their apps use) and return its authKey
    (a session token). Raises RuntimeError with a human-readable message
    on failure. The password is only ever used for this one request -
    it's never stored; only the returned authKey is (in Settings)."""
    body = _api_post("login", {"email": email, "password": password}, timeout)
    error = body.get("error")
    if error:
        raise RuntimeError(error.get("message") or "Login failed")
    auth_key = ((body.get("result") or {}).get("authKey"))
    if not auth_key:
        raise RuntimeError("Stremio didn't return a session key")
    return auth_key


def fetch_watch_progress(imdb_id: str, auth_key: str, timeout: int = 6):
    """Your actual watch progress for this title, from the signed-in
    account's synced Stremio library - unlike fetch_latest_episode
    (which only knows how far the show currently goes, not what you've
    watched), this is the real "what episode am I on". Returns (season,
    episode) ints, or None if you're not signed in, the title isn't in
    your library yet, or the lookup fails."""
    if not auth_key:
        return None
    try:
        body = _api_post("datastoreGet", {
            "authKey": auth_key, "collection": "libraryItem",
            "ids": [imdb_id], "all": False,
        }, timeout)
    except Exception:
        return None
    items = body.get("result") or []
    if not items:
        return None
    # Stremio's library state keys the last-touched video as
    # "<imdb_id>:<season>:<episode>".
    video_id = ((items[0].get("state") or {}).get("video_id")) or ""
    parts = video_id.split(":")
    if len(parts) != 3:
        return None
    try:
        return int(parts[1]), int(parts[2])
    except ValueError:
        return None


def launch(url: str):
    """Open a stremio:// deep link via the OS's registered protocol
    handler (Stremio's installer registers this automatically)."""
    webbrowser.open(url)
